let arr = 10 ;
console.log(arr);
let ar;
console.log(ar);
