Problem 3 : Given an array of numbers find the average of all the even numbers.
  let arr = [1,2,3,4,5,6];
    
      }
        
    }