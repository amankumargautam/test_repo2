var a=100;
var b=.5;
console.log(a**b);