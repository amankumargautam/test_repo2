var n = "Name-Aman Kumar Gautam";
var c = "School-V.N.I.C";
var a = "Grade-B";
var d = "Section-A";
var r = "roll num-fw22_0017";
console.log(`_______                                       
\  ___ \`'.            /|                 .--. 
 ' |--.\  \           ||                 |__| 
 | |    \  '          ||                 .--. 
 | |     |  '         ||  __        __   |  | 
 | |     |  | _    _  ||/'__ '.  .:--.'. |  | 
 | |     ' .'| '  / | |:\`  '. '/ |   \ ||  | 
 | |___.' /'.' | .' | ||     | |\`" __ | ||  | 
/_______.'/ /  | /  | ||\    / ' .'.''| ||__| 
\_______|/ |   \`'.  | |/\'..' / / /   | |_    
           '   .'|  '/'  \`'-'\`  \ \._,\ '/    
            \`-'  \`--'            \`--'  \`" `);
console.log(n);
console.log(c);
console.log(a);
console.log(d);
console.log(r);
