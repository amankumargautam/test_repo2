function addition(){
  let a=10;
  let b=5;
  console.log(a+b);
}
function subtraction(){
  let a=10;
  let b=5;
  console.log(a-b);
}
  function mul(){
  let a=10;
  let b=5;
  console.log(a*b);
  }
    function div(){
  let a=10;
  let b=5;
  console.log(a/b);
    }
addition();
subtraction();
mul();
div();