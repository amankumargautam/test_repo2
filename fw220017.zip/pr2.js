let a=1;
let b=2;
let c=3;
let d=4;
let e=5;
console.log(1*2*3*4*5);
