let arr= 
obj={};
for (let i=0;i<=arrlength-1;i++){
  if(obj[arr[i]])==undefined){
    obj[arr[i]]=1;
  }
  }
}