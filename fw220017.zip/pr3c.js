let a = 5;
let b = 5;
if (a>b){
  console.log("Greater");
}
else {
  console.log("Both equal");
}