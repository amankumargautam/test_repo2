let id  = "amanrediffcom";
let pass = 123456;
let ent_id = "amanrediffcom";
let ent_pass = 123456;
if(id == ent_id){
  if(pass==ent_pass){
    console.log("user can login");
     }else {
    console.log("not login");
     }

}else {
  console.log("wrong id")
}