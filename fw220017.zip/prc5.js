for (let i = 0 ; i<=app_pro.length-1;i++){
  if (app_pro.length.rating>4.2){
    cosole.log(app_pro.length.rating)
  }
}