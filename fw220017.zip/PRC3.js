arr=[2,6,7,12,19,10];
for(let i=1;i<=arr.length-2;i++){
   if(arr[i]%2)
}