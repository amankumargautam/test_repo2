//PROBLEM 4
//Problem 4: Given 3 numbers (all different values), print which is greatest
// let a = 2;
// let b = 4;
// let c = 6;
// if(a>b&&a>c){
//   console.log("a is greatest");
// }else if (b>a&&b>c){
//   console.log("b is greatest");
// }else{
//   console.log("c is greatest");
// }
let a = 8;
let b = 16;
let c = 6;
a>b && a>c ? console.log(" a is gratest")
  :b>a&&b>c ? console.log("b is greatest"):console.log("c is greatest");