const n= "Masai School";
const m = "A Transformation In Education";
console.log(n);
console.log(n);
