var NAME = "AMAN KUMAR GAUTAM";
var FATHER ="SUSHIL KUMAR GAUTAM";
var MOTHER ="BIJMA DEVI";
console.log(NAME);
console.log(FATHER);
console.log(MOTHER);
