//Problem 2: Print the odd numbers from 0 till the given limit
let i = 0;
while (i<=10){
  if (i%2!=0){
    console.log(i);
  }
  i++;
}
