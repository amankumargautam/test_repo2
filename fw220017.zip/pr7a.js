// Given a string count the number of words in that string
let str = "aman gautam";
console.log(str.length);
