//PROBLEM 3
//Problem 3 : Given and character if it is a consonant print "Consonant"
let x = "u";
if(x ==="a" ||x === "e"||x === "i" ||x === "o" || x === "u"){
  console.log("");
}else {
  console.log("consonant");
}