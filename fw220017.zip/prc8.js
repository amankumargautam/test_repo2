function ironman(){
  var x=10;
  var y=15
  
  
}
for(let i=0;i<=6;i++){
   console.log("hello world");
}
print();