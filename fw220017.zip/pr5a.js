//Problem 1: Print the numbers from the given starting point till ending point (including both start and end)
let i = 1;
while (i<=10){
  console.log (i);
  i++;
}