//Problem 5: Given the days of the week in short format "Sun", "Mon" ... print in long format "Sunday", "Monday",
let day = "thur";
switch (day){
  case "sun" : console.log("Sunday");
            break;
  case "mon" : console.log("Monday");
            break;
  case "tues" : console.log("Tuesday");
            break;
  case "wed" : console.log("Wednesday");
            break;
  case "thur" : console.log("Thrusday");
            break;
  case "fri" : console.log("Friday");
            break;
  case "sat" : console.log("Saturday");
            break;
}
  