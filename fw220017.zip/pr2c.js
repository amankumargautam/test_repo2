var one = 1;
var two = 2;
var three = 3;
var four = 4;
var five = 5;
var six = 6;

//let one = 1;
var two = 4;
var three = 9;
var four = 12;
var five = 10;
var six = 12;
var sum = one+two+three+four+five+six;
console.log(sum);