//Given a character in lower case print the upper case character
let str1=[a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z];
let str=[A,B,C,D,E,F,G,H,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z];
let arr=['s'];
for (let i=0;i<str.length;i++){
  if (arr[0]==str1[i]){

console.log(str[i]);
  }
}