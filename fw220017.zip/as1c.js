var name = "AMAN KUMAR GAUTAM";
var age = "25";
console.log(name + age);
console.log(age);
