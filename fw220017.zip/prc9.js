function ironman(x,y){
  console.log(x+y);
}
// ironman(x,y);
ironman(30,40);
ironman(30,40);
ironman(33,40);
ironman(540,40);
ironman(20,40);