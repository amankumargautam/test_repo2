function addition(a,b,c,d){
  console.log(a+b+c+d);
}

  function mul(a,b,c,d){ 
  console.log(a*b);
  }
addition(30,40,50,60);
mul(49,424,42,42);