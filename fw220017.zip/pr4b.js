//Problem 2 : Given any character, if it is a vowel print "Vowel"
let x = "u";
if(x === "a" ||x === "e"||x == "i" ||x === "o" || x === "u"){
  console.log("Vowel");
}